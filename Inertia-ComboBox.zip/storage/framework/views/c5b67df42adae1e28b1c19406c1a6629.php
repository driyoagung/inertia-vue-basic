<?php $__env->startSection('title', 'Todo App (Blade)'); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded bg-white p-6 shadow">
        <div class="mb-4 flex items-center justify-between">
            <h1 class="text-2xl font-bold">Todo App
                <span class="ml-2 rounded bg-orange-100 px-2 py-1 text-xs font-medium text-orange-700">
                    Blade (Server-Side)
                </span>
            </h1>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 rounded bg-green-100 px-3 py-2 text-green-700">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        
        <form action="<?php echo e(route('todos.store')); ?>" method="POST" class="mb-4 flex gap-2">
            <?php echo csrf_field(); ?>
            <input
                type="text"
                name="text"
                value="<?php echo e(old('text')); ?>"
                placeholder="Apa yang ingin dilakukan?"
                class="<?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> flex-1 rounded border px-3 py-2"
                autofocus
            >
            <button type="submit" class="rounded bg-blue-500 px-4 py-2 text-white hover:bg-blue-600">
                Tambah
            </button>
        </form>
        <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="-mt-2 mb-4 text-sm text-red-500"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <div class="mb-4 flex gap-2 text-sm">
            <?php $__currentLoopData = ['all' => 'Semua', 'active' => 'Aktif', 'done' => 'Selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    href="<?php echo e(route('todos.index', ['filter' => $key])); ?>"
                    class="<?php echo e($filter === $key ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'); ?> rounded px-3 py-1"
                >
                    <?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($stats['done'] > 0): ?>
                <form action="<?php echo e(route('todos.clearDone')); ?>" method="POST" class="ml-auto">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="rounded bg-red-500 px-3 py-1 text-white hover:bg-red-600">
                        Hapus selesai (<?php echo e($stats['done']); ?>)
                    </button>
                </form>
            <?php endif; ?>
        </div>

        
        <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center gap-2 border-t py-2">
                
                <form action="<?php echo e(route('todos.update', $todo)); ?>" method="POST" class="contents">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="done" value="<?php echo e($todo->done ? 0 : 1); ?>">
                    <button
                        type="submit"
                        class="flex items-center"
                        title="Toggle selesai"
                    >
                        <?php if($todo->done): ?>
                            <span class="flex h-5 w-5 items-center justify-center rounded border-2 border-green-500 bg-green-500 text-xs font-bold text-white">✓</span>
                        <?php else: ?>
                            <span class="h-5 w-5 rounded border-2 border-gray-300"></span>
                        <?php endif; ?>
                    </button>
                </form>

                
                <span class="<?php echo e($todo->done ? 'text-gray-400 line-through' : ''); ?> flex-1">
                    <?php echo e($todo->text); ?>

                </span>

                <small class="text-xs text-gray-400">
                    <?php echo e($todo->created_at->diffForHumans()); ?>

                </small>

                
                <form action="<?php echo e(route('todos.destroy', $todo)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="text-sm text-red-500 hover:underline">
                        Hapus
                    </button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="py-8 text-center text-gray-400">
                Tidak ada todo.
            </p>
        <?php endif; ?>

        
        <div class="mt-4 border-t pt-4 text-sm text-gray-500">
            Total: <strong><?php echo e($stats['total']); ?></strong> |
            Aktif: <strong><?php echo e($stats['active']); ?></strong> |
            Selesai: <strong><?php echo e($stats['done']); ?></strong>
        </div>
    </div>

    <div class="mt-4 rounded border border-yellow-200 bg-yellow-50 p-4 text-sm text-yellow-800">
        <strong>Catatan:</strong> Versi Blade ini melakukan <em>full page reload</em> setiap aksi (tambah, toggle, hapus). 
        Bandingkan UX-nya dengan versi <a href="<?php echo e(route('todo.inertia')); ?>" class="underline">Inertia</a> di mana UI update reaktif tanpa reload.
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.todo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inertia-vue\resources\views/todo/index.blade.php ENDPATH**/ ?>